#!/bin/bash

printf "\ec"
printf "\nWelcome to use ArbGator script, feel free to visit our website ArbGator.com (https://www.arbgator.com)\n"
printf "\n---------------------------------------------------------------------------------------\n"
printf " \t\t\\t\tMenu"
printf "\n---------------------------------------------------------------------------------------\n"
printf "\n Enter 1 for setup email and password(your required to register at our web site first.\n"
printf "\n Enter 2  to check the latency of all exchanges from your bot.\n"
printf "\n Enter 3 to check the balance and profit (only for test mode)\n"
printf "\n Enter 4 to start the arbitrage bot.\n"
printf "\n Enter 5 to sell a symbol in all exchanges.\n"
printf "\n Enter 6 to update the program.\n"
printf "\n Enter 7 to exit the program.\n\n"

read input

    if [[ "$input" == "1" ]]; then
        echo "Please enter your email address:"
        read email
        echo "Please enter your password:"
        read password

        if [[ "$email" && $password ]]; then
            ./run set $email $password || exit 1
        fi
    fi

    if [[ "$input" == "2" ]]; then
        echo "Checking latency now..."
        ./run latency || exit 1
    fi

    if [[ "$input" == "3" ]]; then
        echo "Checking balance now..."
        ./run balance || exit 1
    fi

    if [[ "$input" == "4" ]]; then
        ./run start || exit 1
    fi

    if [[ "$input" == "5" ]]; then
        echo "Please enter the symbol you want to sell in all exchanges:"
        read symbol
        ./run deleteSymbol $symbol || exit 1
    fi

    if [[ "$input" == "6" ]]; then
        curl "https://arbgator.com/uploads/run_mac.zip" -o tmp.zip && unzip tmp.zip && rm tmp.zip
    fi

    if [[ "$input" == "7" ]]; then
        exit
    fi